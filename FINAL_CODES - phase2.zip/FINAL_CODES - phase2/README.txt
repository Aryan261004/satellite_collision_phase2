Steps to Run the code:

1. cd backend
2. venv\Scripts\activate
3. pip install -r requirements.txt
4. python app.py 
5. click http://127.0.0.1:5000