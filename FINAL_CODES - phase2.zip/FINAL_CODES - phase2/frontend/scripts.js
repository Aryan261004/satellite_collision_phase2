document.addEventListener('DOMContentLoaded', function() {
  
  document.getElementById('year').textContent = new Date().getFullYear();

  const overlay = document.getElementById('overlay');
  const overlayStage = document.querySelector('.overlay-stage');
  const overlayClose = document.getElementById('overlay-close');
  const overlayBack = document.getElementById('overlay-back');

  function openOverlay() {
    overlay.setAttribute('aria-hidden','false');
    overlay.classList.add('open');
  }
  function closeOverlay() {
    overlay.setAttribute('aria-hidden','true');
    overlay.classList.remove('open');
    overlayStage.innerHTML = '<div class="placeholder large">Live simulation iframe / canvas goes here</div>';
  }

  overlayClose.addEventListener('click', closeOverlay);
  overlayBack.addEventListener('click', closeOverlay);

  
  document.querySelectorAll('.nav-links a[href^="#"]').forEach(a=>{
    a.addEventListener('click', function(e){
      const target = document.querySelector(this.getAttribute('href'));
      if(target){ e.preventDefault(); target.scrollIntoView({behavior:'smooth', block:'start'}); }
    });
  });

  
  async function runSimulation(simType) {
    openOverlay();
    if (simType === 'orbit') {
      // Inject interactive simulation HTML
      overlayStage.innerHTML = `
      <div class="container" style="max-width: 1000px; margin: 0 auto;">
        <h1 style="text-align:center;font-size:2em;background:linear-gradient(45deg,#64b5f6,#42a5f5);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">🛰️ Satellite Orbital Dynamics Simulator</h1>
        <div class="simulation-container" style="display:grid;grid-template-columns:1fr 300px;gap:20px;align-items:start;">
          <div class="canvas-container" style="background:rgba(255,255,255,0.1);border-radius:15px;padding:20px;backdrop-filter:blur(10px);box-shadow:0 8px 32px rgba(0,0,0,0.3);">
            <canvas id="orbitCanvas" width="600" height="600"></canvas>
          </div>
          <div class="controls" style="background:rgba(255,255,255,0.1);border-radius:15px;padding:20px;backdrop-filter:blur(10px);box-shadow:0 8px 32px rgba(0,0,0,0.3);">
            <div class="control-group">
              <label for="altitudeSlider">Orbital Altitude</label>
              <input type="range" id="altitudeSlider" min="200" max="2000" value="500" step="50">
              <div class="value-display" id="altitudeValue">500 km</div>
            </div>
            <div class="control-group">
              <label for="speedSlider">Animation Speed</label>
              <input type="range" id="speedSlider" min="0.1" max="3.0" value="1.0" step="0.1">
              <div class="value-display" id="speedValue">1.0x</div>
            </div>
            <div class="control-group">
              <label for="trailLengthSlider">Trail Length</label>
              <input type="range" id="trailLengthSlider" min="10" max="200" value="100" step="10">
              <div class="value-display" id="trailValue">100 points</div>
            </div>
            <button id="playPauseBtn" class="play-btn">▶️ Start Simulation</button>
            <button id="resetBtn" class="reset-btn">🔄 Reset</button>
            <div class="info-panel" style="background:rgba(255,255,255,0.1);border-radius:10px;padding:15px;margin-top:20px;backdrop-filter:blur(10px);">
              <h3 style="margin-top:0;color:#64b5f6;">Orbital Parameters</h3>
              <div class="info-row" style="display:flex;justify-content:space-between;margin:8px 0;font-size:0.9em;">
                <span class="info-label" style="color:#bbdefb;">Orbital Velocity:</span>
                <span class="info-value" id="velocityInfo" style="color:#e3f2fd;font-weight:600;font-family:monospace;">7.6 km/s</span>
              </div>
              <div class="info-row" style="display:flex;justify-content:space-between;margin:8px 0;font-size:0.9em;">
                <span class="info-label" style="color:#bbdefb;">Orbital Period:</span>
                <span class="info-value" id="periodInfo" style="color:#e3f2fd;font-weight:600;font-family:monospace;">94.5 min</span>
              </div>
              <div class="info-row" style="display:flex;justify-content:space-between;margin:8px 0;font-size:0.9em;">
                <span class="info-label" style="color:#bbdefb;">Distance from Earth:</span>
                <span class="info-value" id="distanceInfo" style="color:#e3f2fd;font-weight:600;font-family:monospace;">6878 km</span>
              </div>
              <div class="info-row" style="display:flex;justify-content:space-between;margin:8px 0;font-size:0.9em;">
                <span class="info-label" style="color:#bbdefb;">Current Speed:</span>
                <span class="info-value" id="currentSpeedInfo" style="color:#e3f2fd;font-weight:600;font-family:monospace;">0.0 km/s</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <style>
        .simulation-container{display:grid;grid-template-columns:1fr 300px;gap:20px;align-items:start;}
        .canvas-container{background:rgba(255,255,255,0.1);border-radius:15px;padding:20px;backdrop-filter:blur(10px);box-shadow:0 8px 32px rgba(0,0,0,0.3);}
        #orbitCanvas{border-radius:10px;box-shadow:0 4px 20px rgba(0,0,0,0.5);}
        .controls{background:rgba(255,255,255,0.1);border-radius:15px;padding:20px;backdrop-filter:blur(10px);box-shadow:0 8px 32px rgba(0,0,0,0.3);}
        .control-group{margin-bottom:20px;}
        label{display:block;margin-bottom:8px;font-weight:600;color:#e3f2fd;}
        input[type="range"]{width:100%;margin-bottom:10px;-webkit-appearance:none;appearance:none;height:6px;border-radius:3px;background:rgba(255,255,255,0.3);outline:none;}
        input[type="range"]::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:20px;height:20px;border-radius:50%;background:#42a5f5;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.3);}
        .value-display{background:rgba(66,165,245,0.2);padding:5px 10px;border-radius:5px;font-family:monospace;font-size:0.9em;}
        button{width:100%;padding:12px;margin:5px 0;border:none;border-radius:8px;font-size:1em;font-weight:600;cursor:pointer;transition:all 0.3s ease;}
        .play-btn{background:linear-gradient(45deg,#4caf50,#66bb6a);color:white;}
        .pause-btn{background:linear-gradient(45deg,#ff9800,#ffb74d);color:white;}
        .reset-btn{background:linear-gradient(45deg,#f44336,#ef5350);color:white;}
        button:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,0.3);}
        .info-panel{background:rgba(255,255,255,0.1);border-radius:10px;padding:15px;margin-top:20px;backdrop-filter:blur(10px);}
        .info-row{display:flex;justify-content:space-between;margin:8px 0;font-size:0.9em;}
        .info-label{color:#bbdefb;}
        .info-value{color:#e3f2fd;font-weight:600;font-family:monospace;}
        @media (max-width:768px){.simulation-container{grid-template-columns:1fr;}.canvas-container{order:2;}.controls{order:1;}}
      </style>
      <script id="orbit-sim-script">
        (function(){
        const canvas = document.getElementById('orbitCanvas');
        const ctx = canvas.getContext('2d');
        const G = 6.67430e-11;
        const M_EARTH = 5.972e24;
        const R_EARTH = 6.378e6;
        let animationId = null;
        let isRunning = false;
        let time = 0;
        let satellite = { x: 0, y: 0, vx: 0, vy: 0 };
        let trail = [];
        const altitudeSlider = document.getElementById('altitudeSlider');
        const speedSlider = document.getElementById('speedSlider');
        const trailLengthSlider = document.getElementById('trailLengthSlider');
        const playPauseBtn = document.getElementById('playPauseBtn');
        const resetBtn = document.getElementById('resetBtn');
        const altitudeValue = document.getElementById('altitudeValue');
        const speedValue = document.getElementById('speedValue');
        const trailValue = document.getElementById('trailValue');
        const velocityInfo = document.getElementById('velocityInfo');
        const periodInfo = document.getElementById('periodInfo');
        const distanceInfo = document.getElementById('distanceInfo');
        const currentSpeedInfo = document.getElementById('currentSpeedInfo');
        const scale = canvas.width / (2.5 * (R_EARTH + 2000e3));
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        function initializeSatellite() {
            const altitude = parseFloat(altitudeSlider.value) * 1000;
            const orbitalRadius = R_EARTH + altitude;
            const orbitalVelocity = Math.sqrt(G * M_EARTH / orbitalRadius);
            satellite.x = orbitalRadius;
            satellite.y = 0;
            satellite.vx = 0;
            satellite.vy = orbitalVelocity;
            time = 0;
            trail = [];
            updateOrbitalInfo();
        }
        function updateOrbitalInfo() {
            const altitude = parseFloat(altitudeSlider.value) * 1000;
            const orbitalRadius = R_EARTH + altitude;
            const orbitalVelocity = Math.sqrt(G * M_EARTH / orbitalRadius);
            const orbitalPeriod = 2 * Math.PI * Math.sqrt(Math.pow(orbitalRadius, 3) / (G * M_EARTH));
            velocityInfo.textContent = (orbitalVelocity / 1000).toFixed(1) + ' km/s';
            periodInfo.textContent = (orbitalPeriod / 60).toFixed(1) + ' min';
            distanceInfo.textContent = (orbitalRadius / 1000).toFixed(0) + ' km';
            const currentSpeed = Math.sqrt(satellite.vx * satellite.vx + satellite.vy * satellite.vy);
            currentSpeedInfo.textContent = (currentSpeed / 1000).toFixed(1) + ' km/s';
        }
        function updateSatellite(dt) {
            const r = Math.sqrt(satellite.x * satellite.x + satellite.y * satellite.y);
            const acceleration = G * M_EARTH / (r * r);
            const ax = -acceleration * satellite.x / r;
            const ay = -acceleration * satellite.y / r;
            satellite.vx += ax * dt;
            satellite.vy += ay * dt;
            satellite.x += satellite.vx * dt;
            satellite.y += satellite.vy * dt;
            trail.push({ x: satellite.x, y: satellite.y });
            const maxTrailLength = parseInt(trailLengthSlider.value);
            if (trail.length > maxTrailLength) {
                trail.shift();
            }
            updateOrbitalInfo();
        }
        function drawEarth() {
            const earthRadius = R_EARTH * scale;
            ctx.beginPath();
            ctx.arc(centerX + 2, centerY + 2, earthRadius, 0, 2 * Math.PI);
            ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
            ctx.fill();
            const gradient = ctx.createRadialGradient(
                centerX - earthRadius * 0.3, centerY - earthRadius * 0.3, 0,
                centerX, centerY, earthRadius
            );
            gradient.addColorStop(0, '#4fc3f7');
            gradient.addColorStop(0.6, '#29b6f6');
            gradient.addColorStop(1, '#0277bd');
            ctx.beginPath();
            ctx.arc(centerX, centerY, earthRadius, 0, 2 * Math.PI);
            ctx.fillStyle = gradient;
            ctx.fill();
            ctx.fillStyle = 'rgba(76, 175, 80, 0.8)';
            ctx.beginPath();
            ctx.arc(centerX - earthRadius * 0.2, centerY - earthRadius * 0.1, earthRadius * 0.3, 0, 2 * Math.PI);
            ctx.fill();
            ctx.beginPath();
            ctx.arc(centerX + earthRadius * 0.1, centerY + earthRadius * 0.2, earthRadius * 0.25, 0, 2 * Math.PI);
            ctx.fill();
        }
        function drawTrail() {
            if (trail.length < 2) return;
            ctx.strokeStyle = 'rgba(255, 193, 7, 0.6)';
            ctx.lineWidth = 2;
            ctx.beginPath();
            for (let i = 0; i < trail.length; i++) {
                const point = trail[i];
                const screenX = centerX + point.x * scale;
                const screenY = centerY - point.y * scale;
                if (i === 0) {
                    ctx.moveTo(screenX, screenY);
                } else {
                    ctx.lineTo(screenX, screenY);
                }
                const alpha = i / trail.length;
                ctx.globalAlpha = alpha * 0.6;
            }
            ctx.globalAlpha = 1;
            ctx.stroke();
        }
        function drawSatellite() {
            const screenX = centerX + satellite.x * scale;
            const screenY = centerY - satellite.y * scale;
            const gradient = ctx.createRadialGradient(screenX, screenY, 0, screenX, screenY, 15);
            gradient.addColorStop(0, 'rgba(244, 67, 54, 0.8)');
            gradient.addColorStop(1, 'rgba(244, 67, 54, 0)');
            ctx.fillStyle = gradient;
            ctx.beginPath();
            ctx.arc(screenX, screenY, 15, 0, 2 * Math.PI);
            ctx.fill();
            ctx.fillStyle = '#f44336';
            ctx.beginPath();
            ctx.arc(screenX, screenY, 4, 0, 2 * Math.PI);
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 2;
            ctx.stroke();
        }
        function animate() {
            const animationSpeed = parseFloat(speedSlider.value);
            const dt = 20 * animationSpeed;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
            gradient.addColorStop(0, '#0a1a2a');
            gradient.addColorStop(1, '#1a2332');
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = 'white';
            for (let i = 0; i < 50; i++) {
                const x = (i * 37) % canvas.width;
                const y = (i * 67) % canvas.height;
                const size = Math.sin(time * 0.01 + i) * 0.5 + 1;
                ctx.globalAlpha = Math.sin(time * 0.005 + i) * 0.3 + 0.7;
                ctx.beginPath();
                ctx.arc(x, y, size, 0, 2 * Math.PI);
                ctx.fill();
            }
            ctx.globalAlpha = 1;
            updateSatellite(dt);
            drawTrail();
            drawEarth();
            drawSatellite();
            time += dt;
            if (isRunning) {
                animationId = requestAnimationFrame(animate);
            }
        }
        altitudeSlider.addEventListener('input', (e) => {
            altitudeValue.textContent = e.target.value + ' km';
            if (!isRunning) {
                initializeSatellite();
                animate();
            }
        });
        speedSlider.addEventListener('input', (e) => {
            speedValue.textContent = e.target.value + 'x';
        });
        trailLengthSlider.addEventListener('input', (e) => {
            trailValue.textContent = e.target.value + ' points';
        });
        playPauseBtn.addEventListener('click', () => {
            if (isRunning) {
                isRunning = false;
                cancelAnimationFrame(animationId);
                playPauseBtn.textContent = '▶️ Resume';
                playPauseBtn.className = 'play-btn';
            } else {
                isRunning = true;
                animate();
                playPauseBtn.textContent = '⏸️ Pause';
                playPauseBtn.className = 'pause-btn';
            }
        });
        resetBtn.addEventListener('click', () => {
            isRunning = false;
            cancelAnimationFrame(animationId);
            initializeSatellite();
            animate();
            playPauseBtn.textContent = '▶️ Start Simulation';
            playPauseBtn.className = 'play-btn';
        });
        initializeSatellite();
        animate();
        })();
      </script>
      `;
      // Dynamically evaluate the script tag (since innerHTML doesn't execute it)
      const simScript = overlayStage.querySelector('#orbit-sim-script');
      if (simScript) {
        const newScript = document.createElement('script');
        newScript.textContent = simScript.textContent;
        document.body.appendChild(newScript);
        document.body.removeChild(newScript);
      }
      return;
    }
    if (simType === 'collisions') {
      // Inject TLE-based real satellites 3D viewer (Three.js)
      overlayStage.innerHTML = `
      <div class="tle-wrapper" style="width:100%;max-width:1000px;margin:0 auto;">
      <div class="container" style="display:grid;grid-template-columns:1fr 300px;gap:20px;align-items:start;padding:0;">
        <div class="main-view" style="height:60vh;background:rgba(0,0,0,0.5);border-radius:15px;overflow:hidden;position:relative;box-shadow:0 8px 32px rgba(0,0,0,0.5);">
          <div id="canvas-container" style="width:100%;height:100%;"></div>
          <div class="view-info" style="position:absolute;top:20px;left:20px;background:rgba(0,0,0,0.7);padding:10px 15px;border-radius:8px;font-size:0.85em;z-index:10;">
            <div style="color:#00d4ff;font-weight:bold;margin-bottom:5px;">🌍 3D Orbit View</div>
            <div style="font-size:0.8em;">Drag: Rotate | Scroll: Zoom</div>
          </div>
        </div>
        <div class="controls-panel" style="background:rgba(0,0,0,0.85);border-radius:15px;padding:20px;backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,0.2);overflow:auto;box-shadow:0 8px 32px rgba(0,0,0,0.5);max-height:60vh;">
          <h1 style="font-size:1.3em;margin-bottom:15px;background:linear-gradient(45deg,#00d4ff,#0099ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-align:center;">🛰️ TLE Orbit Viewer</h1>
          <div class="control-section" style="margin-bottom:20px;padding-bottom:15px;border-bottom:1px solid rgba(255,255,255,0.1);">
            <h3 style="font-size:1em;margin-bottom:10px;color:#00d4ff;">Select Satellites</h3>
            <div id="satellite-list"></div>
          </div>
          <div class="control-section" style="margin-bottom:20px;padding-bottom:15px;border-bottom:1px solid rgba(255,255,255,0.1);">
            <h3 style="font-size:1em;margin-bottom:10px;color:#00d4ff;">Animation Controls</h3>
            <button id="playPauseBtn" class="play-btn" style="background:linear-gradient(45deg,#4caf50,#66bb6a);color:white;width:100%;padding:10px;margin:5px 0;border:none;border-radius:8px;font-size:0.9em;font-weight:600;cursor:pointer;">▶️ Start Animation</button>
            <button id="resetBtn" class="reset-btn" style="background:linear-gradient(45deg,#f44336,#ef5350);color:white;width:100%;padding:10px;margin:5px 0;border:none;border-radius:8px;font-size:0.9em;font-weight:600;cursor:pointer;">🔄 Reset View</button>
          </div>
          <div class="control-section" style="margin-bottom:20px;padding-bottom:15px;border-bottom:1px solid rgba(255,255,255,0.1);">
            <div class="slider-group" style="margin:10px 0;">
              <label for="speedSlider" style="display:block;font-size:0.85em;margin-bottom:5px;color:#b0b0b0;">Animation Speed</label>
              <input type="range" id="speedSlider" min="0.1" max="3" value="1" step="0.1" style="width:100%;height:5px;border-radius:3px;background:rgba(255,255,255,0.2);outline:none;">
              <div class="value-display" id="speedValue" style="text-align:right;font-size:0.85em;color:#00d4ff;font-family:monospace;">1.0x</div>
            </div>
            <div class="slider-group" style="margin:10px 0;">
              <label for="earthSizeSlider" style="display:block;font-size:0.85em;margin-bottom:5px;color:#b0b0b0;">Earth Size</label>
              <input type="range" id="earthSizeSlider" min="0.5" max="2" value="1" step="0.1" style="width:100%;height:5px;border-radius:3px;background:rgba(255,255,255,0.2);outline:none;">
              <div class="value-display" id="earthSizeValue" style="text-align:right;font-size:0.85em;color:#00d4ff;font-family:monospace;">1.0x</div>
            </div>
          </div>
          <div class="info-panel" style="background:rgba(0,0,0,0.7);padding:15px;border-radius:10px;margin-top:10px;font-size:0.85em;">
            <div class="info-row" style="margin:5px 0;display:flex;justify-content:space-between;"><span class="info-label" style="color:#b0b0b0;">Active Satellites:</span><span class="info-value" id="activeSats" style="color:#00d4ff;font-family:monospace;">6</span></div>
            <div class="info-row" style="margin:5px 0;display:flex;justify-content:space-between;"><span class="info-label" style="color:#b0b0b0;">Total Orbits:</span><span class="info-value" style="color:#00d4ff;font-family:monospace;">6</span></div>
          </div>
        </div>
      </div>
      </div>
      <script id="tle-sim-script">
        (function(){
        const MU = 398600.4418;
        const R_EARTH = 6371;
        const ORBIT_SCALE = 1.0;
        const TLE_DATA = {
          "ISS (ZARYA)": { line1: "1 25544U 98067A   25040.50000000  .00016717  00000-0  10270-3 0  9005", line2: "2 25544  51.6400 208.5800 0002710  45.8100  73.2900 15.50030000123456", color: 0xff6b6b },
          "HUBBLE": { line1: "1 20580U 90037B   25040.50000000  .00001234  00000-0  56789-4 0  9008", line2: "2 20580  28.4700 150.3200 0003000  12.4500 347.6500 15.09678934123456", color: 0x4ecdc4 },
          "LILACSAT-2": { line1: "1 40908U 15049K   25040.75362640  .00014926  00000-0  44552-3 0  9999", line2: "2 40908  97.5165  58.4844 0008714 220.7406 139.3186 15.34689321519828", color: 0xffe66d },
          "AO-07": { line1: "1 07530U 74089B   25248.59614920 -.00000014  00000-0  20180-3 0  9990", line2: "2 07530 101.9976 253.8073 0012015 315.7523 162.7217 12.53691377324855", color: 0x95e1d3 },
          "STARLINK-1007": { line1: "1 44713U 19074A   25040.50000000  .00002345  00000-0  17890-3 0  9991", line2: "2 44713  53.0530 123.4560 0001234  89.1200 270.9800 15.06378923298765", color: 0xf38181 },
          "NOAA-18": { line1: "1 28654U 05018A   25040.50000000  .00000234  00000-0  14567-3 0  9995", line2: "2 28654  99.0450  45.6780 0014234 234.5670 125.4330 14.12501234987654", color: 0xaa96da }
        };
        const container = document.getElementById('canvas-container');
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x000000);
        const camera = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 500000);
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(container.clientWidth, container.clientHeight);
        container.appendChild(renderer.domElement);
        camera.position.set(30000, 20000, 30000);
        camera.lookAt(0, 0, 0);
        const starGeometry = new THREE.BufferGeometry();
        const starVertices = [];
        for (let i = 0; i < 10000; i++) { const x = (Math.random() - 0.5) * 200000; const y = (Math.random() - 0.5) * 200000; const z = (Math.random() - 0.5) * 200000; starVertices.push(x, y, z); }
        starGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starVertices, 3));
        const starMaterial = new THREE.PointsMaterial({ color: 0xffffff, size: 100 });
        const stars = new THREE.Points(starGeometry, starMaterial);
        scene.add(stars);
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.8); scene.add(ambientLight);
        const sunLight = new THREE.DirectionalLight(0xffffff, 1.2); sunLight.position.set(50000, 30000, 50000); scene.add(sunLight);
        const backLight = new THREE.DirectionalLight(0x8888ff, 0.4); backLight.position.set(-50000, 0, 0); scene.add(backLight);
        let earthGroup = new THREE.Group();
        const earthGeometry = new THREE.SphereGeometry(R_EARTH, 64, 64);
        const earthMaterial = new THREE.MeshPhongMaterial({ color: 0x4488ff, emissive: 0x001133, shininess: 20, specular: 0x444444 });
        const earth = new THREE.Mesh(earthGeometry, earthMaterial); earthGroup.add(earth);
        const canvas = document.createElement('canvas'); canvas.width = 1024; canvas.height = 512; const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#1155aa'; ctx.fillRect(0, 0, canvas.width, canvas.height); ctx.fillStyle = '#228844';
        ctx.beginPath(); ctx.ellipse(150, 150, 100, 120, 0, 0, 2*Math.PI); ctx.fill();
        ctx.beginPath(); ctx.ellipse(200, 320, 60, 100, 0, 0, 2*Math.PI); ctx.fill();
        ctx.beginPath(); ctx.ellipse(512, 200, 80, 140, 0, 0, 2*Math.PI); ctx.fill();
        ctx.beginPath(); ctx.ellipse(700, 150, 150, 100, 0, 0, 2*Math.PI); ctx.fill();
        ctx.beginPath(); ctx.ellipse(800, 380, 70, 50, 0, 0, 2*Math.PI); ctx.fill();
        const texture = new THREE.CanvasTexture(canvas);
        const texturedEarthMaterial = new THREE.MeshPhongMaterial({ map: texture, shininess: 15, specular: 0x333333 });
        const texturedEarth = new THREE.Mesh(earthGeometry, texturedEarthMaterial); earthGroup.add(texturedEarth);
        const glowGeometry = new THREE.SphereGeometry(R_EARTH * 1.05, 32, 32);
        const glowMaterial = new THREE.MeshBasicMaterial({ color: 0x4488ff, transparent: true, opacity: 0.1, side: THREE.BackSide });
        const glow = new THREE.Mesh(glowGeometry, glowMaterial); earthGroup.add(glow);
        scene.add(earthGroup);
        const satelliteOrbits = {}; const activeSatellites = new Set();
        function parseTLE(name, tle){
          const line2 = tle.line2;
          const inclination = parseFloat(line2.substring(8,16)) * Math.PI/180;
          const raan = parseFloat(line2.substring(17,25)) * Math.PI/180;
          const eccentricity = parseFloat("0." + line2.substring(26,33));
          const argPerigee = parseFloat(line2.substring(34,42)) * Math.PI/180;
          const meanMotion = parseFloat(line2.substring(52,63));
          const n = meanMotion * 2 * Math.PI / (24 * 3600 * 0.997269);
          const a = Math.pow(MU / (n*n), 1/3);
          const b = a * Math.sqrt(1 - eccentricity*eccentricity);
          const c = a * eccentricity;
          return { a, b, c, inclination, raan, argPerigee, eccentricity, name };
        }
        function createOrbit(orbitData, color){
          const points = []; const numPoints = 200;
          for (let i=0;i<=numPoints;i++){
            const theta = (i/numPoints) * 2*Math.PI;
            const x = orbitData.a * Math.cos(theta) - orbitData.c;
            const y = orbitData.b * Math.sin(theta);
            const z = 0;
            const cosRaan = Math.cos(orbitData.raan), sinRaan = Math.sin(orbitData.raan);
            const cosInc = Math.cos(orbitData.inclination), sinInc = Math.sin(orbitData.inclination);
            const cosArg = Math.cos(orbitData.argPerigee), sinArg = Math.sin(orbitData.argPerigee);
            let x1 = x * cosArg - y * sinArg; let y1 = x * sinArg + y * cosArg; let z1 = z;
            let x2 = x1; let y2 = y1 * cosInc - z1 * sinInc; let z2 = y1 * sinInc + z1 * cosInc;
            let x3 = x2 * cosRaan - y2 * sinRaan; let y3 = x2 * sinRaan + y2 * cosRaan; let z3 = z2;
            points.push(new THREE.Vector3(x3*ORBIT_SCALE, z3*ORBIT_SCALE, y3*ORBIT_SCALE));
          }
          const geometry = new THREE.BufferGeometry().setFromPoints(points);
          const material = new THREE.LineBasicMaterial({ color: color, linewidth: 3, transparent: true, opacity: 0.8 });
          const orbit = new THREE.Line(geometry, material);
          const satGeometry = new THREE.SphereGeometry(300, 16, 16);
          const satMaterial = new THREE.MeshBasicMaterial({ color: color });
          const satellite = new THREE.Mesh(satGeometry, satMaterial);
          const glowGeometry2 = new THREE.SphereGeometry(500, 16, 16);
          const glowMaterial2 = new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.3 });
          const satGlow = new THREE.Mesh(glowGeometry2, glowMaterial2); satellite.add(satGlow);
          return { orbit, satellite, points, orbitData };
        }
        let isAnimating = false; let animationFrame = 0; let animationSpeed = 1.0;
        function initializeSatellites(){
          Object.keys(TLE_DATA).forEach(name=>{
            const tle = TLE_DATA[name];
            const orbitData = parseTLE(name, tle);
            const orbitVis = createOrbit(orbitData, tle.color);
            satelliteOrbits[name] = orbitVis;
            const listItem = document.createElement('div');
            listItem.className = 'satellite-item';
            listItem.style.display = 'flex'; listItem.style.alignItems = 'center'; listItem.style.margin = '8px 0'; listItem.style.padding = '8px'; listItem.style.background = 'rgba(255,255,255,0.05)'; listItem.style.borderRadius = '8px'; listItem.style.cursor = 'pointer';
            listItem.innerHTML =
              '<input type="checkbox" class="satellite-checkbox" id="sat-' + name + '" checked style="margin-right:10px;width:18px;height:18px;cursor:pointer;" />' +
              '<div class="satellite-color" style="width:20px;height:20px;border-radius:50%;margin-right:10px;border:2px solid white;box-shadow:0 0 10px rgba(255,255,255,0.5);background-color:#' + tle.color.toString(16).padStart(6,'0') + '"></div>' +
              '<span class="satellite-name" style="flex-grow:1;font-size:0.9em;">' + name + '</span>';
            listItem.addEventListener('click',(e)=>{ if (e.target !== listItem.querySelector('input')) { const checkbox = listItem.querySelector('input'); checkbox.checked = !checkbox.checked; checkbox.dispatchEvent(new Event('change')); } });
            const checkbox = listItem.querySelector('input');
            checkbox.addEventListener('change',(e)=>{ toggleSatellite(name, e.target.checked); });
            document.getElementById('satellite-list').appendChild(listItem);
            activeSatellites.add(name); scene.add(orbitVis.orbit); scene.add(orbitVis.satellite);
          });
          updateActiveSatelliteCount();
        }
        function toggleSatellite(name, show){
          const orbitVis = satelliteOrbits[name];
          if (show) { activeSatellites.add(name); scene.add(orbitVis.orbit); scene.add(orbitVis.satellite); }
          else { activeSatellites.delete(name); scene.remove(orbitVis.orbit); scene.remove(orbitVis.satellite); }
          updateActiveSatelliteCount();
        }
        function updateActiveSatelliteCount(){ document.getElementById('activeSats').textContent = activeSatellites.size; }
        function animate(){
          requestAnimationFrame(animate);
          if (isAnimating){
            animationFrame += animationSpeed * 0.5;
            activeSatellites.forEach(name=>{ const orbitVis = satelliteOrbits[name]; const index = Math.floor(animationFrame) % orbitVis.points.length; const point = orbitVis.points[index]; orbitVis.satellite.position.copy(point); });
          }
          earthGroup.rotation.y += 0.0005; renderer.render(scene, camera);
        }
        let isDragging = false; let previousMousePosition = { x: 0, y: 0 };
        renderer.domElement.addEventListener('mousedown',(e)=>{ isDragging = true; previousMousePosition = { x: e.clientX, y: e.clientY }; });
        renderer.domElement.addEventListener('mousemove',(e)=>{
          if (isDragging){
            const deltaX = e.clientX - previousMousePosition.x; const deltaY = e.clientY - previousMousePosition.y; const rotationSpeed = 0.005;
            const yAxis = new THREE.Vector3(0,1,0); camera.position.applyAxisAngle(yAxis, -deltaX * rotationSpeed);
            const xAxis = new THREE.Vector3(1,0,0); const newPosition = camera.position.clone(); newPosition.applyAxisAngle(xAxis, -deltaY * rotationSpeed);
            if (newPosition.y > -50000){ camera.position.copy(newPosition); }
            camera.lookAt(0,0,0); previousMousePosition = { x: e.clientX, y: e.clientY };
          }
        });
        renderer.domElement.addEventListener('mouseup',()=>{ isDragging = false; });
        renderer.domElement.addEventListener('wheel',(e)=>{
          e.preventDefault(); const zoomSpeed = 0.1; const distance = camera.position.length(); const minDistance = 15000; const maxDistance = 100000; const newDistance = distance * (1 + (e.deltaY > 0 ? zoomSpeed : -zoomSpeed));
          if (newDistance >= minDistance && newDistance <= maxDistance){ camera.position.multiplyScalar(newDistance / distance); }
        }, { passive: false });
        document.getElementById('playPauseBtn').addEventListener('click',(e)=>{
          isAnimating = !isAnimating; if (isAnimating){ e.target.textContent = '⏸️ Pause'; e.target.className = 'pause-btn'; } else { e.target.textContent = '▶️ Start Animation'; e.target.className = 'play-btn'; }
        });
        document.getElementById('resetBtn').addEventListener('click',()=>{ camera.position.set(30000, 20000, 30000); camera.lookAt(0,0,0); animationFrame = 0; });
        document.getElementById('speedSlider').addEventListener('input',(e)=>{ animationSpeed = parseFloat(e.target.value); document.getElementById('speedValue').textContent = animationSpeed.toFixed(1) + 'x'; });
        document.getElementById('earthSizeSlider').addEventListener('input',(e)=>{ const scale = parseFloat(e.target.value); earthGroup.scale.set(scale, scale, scale); document.getElementById('earthSizeValue').textContent = scale.toFixed(1) + 'x'; });
        window.addEventListener('resize',()=>{ const width = container.clientWidth; const height = container.clientHeight; camera.aspect = width/height; camera.updateProjectionMatrix(); renderer.setSize(width, height); });
        initializeSatellites();
        animate();
        })();
      </script>
      `;
      // Ensure Three.js is loaded, then execute inline script
      const loadExternalScript = (src) => new Promise((resolve, reject) => {
        const s = document.createElement('script'); s.src = src; s.onload = resolve; s.onerror = reject; document.body.appendChild(s);
      });
      try {
        if (typeof THREE === 'undefined') {
          await loadExternalScript('https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js');
        }
        const simScript = overlayStage.querySelector('#tle-sim-script');
        if (simScript) {
          const newScript = document.createElement('script');
          newScript.textContent = simScript.textContent;
          document.body.appendChild(newScript);
          document.body.removeChild(newScript);
        }
      } catch (e) {
        overlayStage.innerHTML = `<div style="color:#ff9b9b">Failed to load Three.js: ${e.message}</div>`;
      }
      return;
    }
    if (simType === 'particle') {
      // Inject Collision Risk Analyzer (SGP4) UI
      overlayStage.innerHTML = `
      <div class="analyzer-wrapper" style="height:100%;overflow:auto;padding:8px 0;">
      <style>
        /* Improve dropdown readability across platforms */
        .analyzer-card select { color:#ffffff; background: rgba(255,255,255,0.06); }
        .analyzer-card select option { color:#111111; background:#ffffff; }
        /* Results styles */
        .results-grid { display:grid; grid-template-columns: 1fr auto; gap:10px; }
        .res-label { color:#9fb0c9; font-size:0.9rem; }
        .res-value { color:#e8f0ff; font-weight:700; font-family:monospace; }
        .status-chip { display:inline-flex; align-items:center; gap:8px; padding:6px 10px; border-radius:999px; font-weight:700; }
        .status-ok { background: rgba(76, 175, 80, 0.18); color:#b8ffbf; border:1px solid rgba(76,175,80,0.35); }
        .status-warn { background: rgba(255, 107, 107, 0.18); color:#ffb3b3; border:1px solid rgba(255,107,107,0.35); }
        .divider { height:1px; background:rgba(255,255,255,0.08); margin:10px 0; }
      </style>
      <div class="analyzer-card" style="width:100%;max-width:1200px;margin:0 auto;display:grid;grid-template-columns:360px 1fr;gap:18px;">
        <div class="controls-panel" style="background:rgba(0,0,0,0.86);border-radius:12px;padding:18px;border:1px solid rgba(255,255,255,0.08);overflow:auto;position:relative;">
          <button id="closeAnalyzerBtn" style="position:absolute;top:12px;right:12px;background:rgba(0,0,0,0.5);border-radius:6px;padding:8px;cursor:pointer;border:1px solid rgba(255,255,255,0.06);color:#fff;">✕</button>
          <h1 style="text-align:center;font-size:1.4rem;margin-bottom:12px;background:linear-gradient(45deg,#ff6b6b,#ee5a6f);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">⚠️ Collision Risk Analyzer</h1>
          
          <div class="control-section" style="margin-bottom:14px;border-bottom:1px solid rgba(255,255,255,0.04);padding-bottom:12px;">
            <h3 style="color:#ff6b6b;font-size:1.05rem;margin-bottom:8px;">Select Satellites</h3>
            <label for="sat1Select" style="display:block;font-size:0.85rem;color:#bfc7d6;margin-bottom:6px;">Satellite 1</label>
            <select id="sat1Select" style="width:100%;padding:8px 10px;border-radius:6px;border:1px solid rgba(255,255,255,0.06);background:rgba(255,255,255,0.03);color:#fff;font-size:0.95rem;"></select>
            <label for="sat2Select" style="display:block;font-size:0.85rem;color:#bfc7d6;margin:10px 0 6px;">Satellite 2</label>
            <select id="sat2Select" style="width:100%;padding:8px 10px;border-radius:6px;border:1px solid rgba(255,255,255,0.06);background:rgba(255,255,255,0.03);color:#fff;font-size:0.95rem;"></select>
            <div id="fileInfo" style="margin-top:10px;font-size:0.85rem;color:#bfc7d6;">Loading TLEs from server...</div>
          </div>
          <div class="control-section" style="margin-bottom:14px;border-bottom:1px solid rgba(255,255,255,0.04);padding-bottom:12px;">
            <h3 style="color:#ff6b6b;font-size:1.05rem;margin-bottom:8px;">Search Window</h3>
            <label for="startTime" style="display:block;font-size:0.85rem;color:#bfc7d6;margin-bottom:6px;">Start Time (UTC)</label>
            <input type="datetime-local" id="startTime" value="2025-11-05T18:47:00" style="width:100%;padding:8px 10px;border-radius:6px;border:1px solid rgba(255,255,255,0.06);background:rgba(255,255,255,0.03);color:#fff;">
            <label for="duration" style="display:block;font-size:0.85rem;color:#bfc7d6;margin:10px 0 6px;">Duration (hours)</label>
            <input type="number" id="duration" value="12" min="1" max="168" step="1" style="width:100%;padding:8px 10px;border-radius:6px;border:1px solid rgba(255,255,255,0.06);background:rgba(255,255,255,0.03);color:#fff;">
          </div>
          <div class="control-section" style="margin-bottom:14px;border-bottom:1px solid rgba(255,255,255,0.04);padding-bottom:12px;">
            <h3 style="color:#ff6b6b;font-size:1.05rem;margin-bottom:8px;">Analysis Parameters</h3>
            <label for="threshold" style="display:block;font-size:0.85rem;color:#bfc7d6;margin-bottom:6px;">Collision Threshold (km)</label>
            <input type="number" id="threshold" value="10" min="0.1" max="100" step="0.1" style="width:100%;padding:8px 10px;border-radius:6px;border:1px solid rgba(255,255,255,0.06);background:rgba(255,255,255,0.03);color:#fff;">
            <label for="samples" style="display:block;font-size:0.85rem;color:#bfc7d6;margin:10px 0 6px;">Sample Points</label>
            <input type="number" id="samples" value="1200" min="100" max="5000" step="100" style="width:100%;padding:8px 10px;border-radius:6px;border:1px solid rgba(255,255,255,0.06);background:rgba(255,255,255,0.03);color:#fff;">
          </div>
          <button id="analyzeBtn" style="width:100%;padding:10px;border-radius:8px;border:none;font-weight:600;cursor:pointer;background:linear-gradient(45deg,#ff6b6b,#ee5a6f);color:#fff;">🔍 Analyze Collision Risk</button>
          <button id="resetBtn" style="width:100%;padding:10px;border-radius:8px;border:none;font-weight:600;cursor:pointer;margin-top:8px;background:linear-gradient(45deg,#4ecdc4,#44a08d);color:#062b2b;">🔄 Reset View</button>
          <div style="margin-top:8px;font-size:0.85rem;color:#cbd5e1;">Tip: TLE files commonly come as repeated 3-line groups (name / line1 / line2) or repeated 2-line groups (line1 / line2). This parser accepts both.</div>
        </div>
        <div class="main-view" style="display:flex;flex-direction:column;gap:12px;max-height:75vh;height:75vh;overflow:hidden;">
          <div class="visualization" style="flex:1;position:relative;background:rgba(0,0,0,0.45);border-radius:12px;overflow:hidden;min-height:45vh;">
            <div id="canvas-container" style="width:100%;height:100%;"></div>
            <div class="view-info" style="position:absolute;top:12px;left:12px;background:rgba(0,0,0,0.6);padding:8px 10px;border-radius:8px;font-size:0.85rem;z-index:10;">
              <div style="color:#ff6b6b;font-weight:700;">🛰️ Trajectory View</div>
              <div style="font-size:0.85rem;color:#cbd5e1;">Drag: Rotate | Scroll: Zoom</div>
            </div>
          </div>
          <div class="results-panel" style="background:rgba(0,0,0,0.86);border-radius:12px;padding:14px;border:1px solid rgba(255,255,255,0.06);flex:0 0 28vh;max-height:28vh;min-height:24vh;overflow:auto;">
            <h2 style="color:#ff6b6b;font-size:1.1rem;margin:0 0 8px 0;">Analysis Results</h2>
            <div id="results">
              <div style="text-align:center;padding:20px;color:#888;">Load a TLE file and click \"Analyze Collision Risk\"</div>
            </div>
          </div>
        </div>
      </div>
      </div>`;
      // Load external libraries then execute analyzer script
      const loadScript = (src) => new Promise((resolve, reject) => { const s = document.createElement('script'); s.src = src; s.onload = resolve; s.onerror = reject; document.body.appendChild(s); });
      try {
        if (typeof THREE === 'undefined') { await loadScript('https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js'); }
        if (typeof satellite === 'undefined') { await loadScript('https://cdnjs.cloudflare.com/ajax/libs/satellite.js/4.0.0/satellite.min.js'); }
        const scriptContent = `
          (function(){
            function closeAnalyzer(){ try { document.getElementById('overlay-close').click(); } catch(e) {} }
            const closeBtn = document.getElementById('closeAnalyzerBtn'); if (closeBtn) closeBtn.addEventListener('click', closeAnalyzer);
            function parseTLEText(tleText){ const lines = tleText.split(/\\r?\\n/).map(l=>l.trim()).filter(l=>l.length>0); const sets=[]; let i=0; while(i<lines.length){ const line=lines[i]; if(/^[12]\\s/.test(line) && i+1<lines.length && /^[12]\\s/.test(lines[i+1])){ const line1=lines[i]; const line2=lines[i+1]; const name=\`SAT_\${line1.substring(2,7).trim()}\`; sets.push({name,line1,line2}); i+=2; } else if(!/^[12]\\s/.test(line) && i+2<lines.length && /^[12]\\s/.test(lines[i+1]) && /^[12]\\s/.test(lines[i+2])){ const name=lines[i]; const line1=lines[i+1]; const line2=lines[i+2]; sets.push({name,line1,line2}); i+=3; } else { if(i+1<lines.length && /^[12]\\s/.test(lines[i]) && /^[12]\\s/.test(lines[i+1])){ sets.push({ name: \`SAT_\${lines[i].substring(2,7).trim()}\`, line1: lines[i], line2: lines[i+1] }); i+=2; } else { i+=1; } } } return sets; }
            function colorFromString(s){ let h=0; for(let i=0;i<s.length;i++) h=(h*31+s.charCodeAt(i))&0xffffffff; const r=(h>>16)&0xff, g=(h>>8)&0xff, b=h&0xff; return (r<<16)+(g<<8)+b; }
            const fileInfo=document.getElementById('fileInfo'); let parsedTLEs=[];
            async function loadDefaultTLE(){
              const candidates=['/api/tle','/static/tle.txt','/static/data/tle.txt','/tle.txt'];
              const fetchWithTimeout=(url,ms=8000)=>Promise.race([
                fetch(url, { cache:'no-store' }),
                new Promise((_,rej)=>setTimeout(()=>rej(new Error('timeout')), ms))
              ]);
              for (const base of candidates){
                const url = base + (base.includes('?')?'&':'?') + 't=' + Date.now();
                try {
                  const resp = await fetchWithTimeout(url);
                  if (!resp.ok) continue;
                  const text = await resp.text();
                  const sets = parseTLEText(text);
                  if (!sets || sets.length === 0) continue;
                  parsedTLEs = sets.map(s=>{
                    const color=colorFromString(s.name);
                    let satrec=null; try{ satrec=satellite.twoline2satrec(s.line1,s.line2);}catch(e){ satrec=null; }
                    return { name:s.name, line1:s.line1, line2:s.line2, color, satrec };
                  });
                  populateSatelliteSelects();
                  // Select first two by default if available
                  const s1=document.getElementById('sat1Select'); const s2=document.getElementById('sat2Select');
                  if (s1 && s1.options.length>1) s1.selectedIndex = 1;
                  if (s2 && s2.options.length>2) s2.selectedIndex = 2; else if (s2 && s2.options.length>1) s2.selectedIndex = 1;
                  if (fileInfo) fileInfo.textContent = parsedTLEs.length + ' TLE sets loaded from server';
                  return;
                } catch (e) {
                  console.error('TLE fetch failed for', url, e);
                  continue;
                }
              }
              if (fileInfo) fileInfo.textContent = 'Failed to load TLEs from server.';
            }
            function populateSatelliteSelects(){ const s1=document.getElementById('sat1Select'); const s2=document.getElementById('sat2Select'); s1.innerHTML=''; s2.innerHTML=''; const hint=document.createElement('option'); hint.value=''; hint.textContent='-- Select Satellite --'; s1.appendChild(hint.cloneNode(true)); s2.appendChild(hint.cloneNode(true)); parsedTLEs.forEach((t,idx)=>{ const o1=document.createElement('option'); o1.value=String(idx); o1.textContent=t.name; s1.appendChild(o1); const o2=document.createElement('option'); o2.value=String(idx); o2.textContent=t.name; s2.appendChild(o2); }); }
            const container=document.getElementById('canvas-container'); const scene=new THREE.Scene(); scene.background=new THREE.Color(0x000000); const camera=new THREE.PerspectiveCamera(60,1,0.1,500000); camera.position.set(30000,20000,30000); camera.lookAt(0,0,0); let renderer=null; const ambientLight=new THREE.AmbientLight(0xffffff,0.6); const sunLight=new THREE.DirectionalLight(0xffffff,1.0); sunLight.position.set(50000,30000,50000);
            const R_EARTH=6378; const earthGroup=new THREE.Group(); const earthGeometry=new THREE.SphereGeometry(R_EARTH,64,64); const canvasTex=document.createElement('canvas'); canvasTex.width=1024; canvasTex.height=512; const cctx=canvasTex.getContext('2d'); cctx.fillStyle='#1155aa'; cctx.fillRect(0,0,canvasTex.width,canvasTex.height); cctx.fillStyle='#228844'; cctx.beginPath(); cctx.ellipse(240,140,120,150,0,0,2*Math.PI); cctx.fill(); cctx.beginPath(); cctx.ellipse(380,340,90,140,0,0,2*Math.PI); cctx.fill(); cctx.beginPath(); cctx.ellipse(640,160,100,160,0,0,2*Math.PI); cctx.fill(); const earthTexture=new THREE.CanvasTexture(canvasTex); const earthMaterial=new THREE.MeshPhongMaterial({ map: earthTexture, shininess:10 }); const earthMesh=new THREE.Mesh(earthGeometry,earthMaterial); earthGroup.add(earthMesh);
            const starGeometry=new THREE.BufferGeometry(); const starVertices=new Float32Array(5000*3); for(let i=0;i<5000;i++){ starVertices[i*3+0]=(Math.random()-0.5)*200000; starVertices[i*3+1]=(Math.random()-0.5)*200000; starVertices[i*3+2]=(Math.random()-0.5)*200000; } starGeometry.setAttribute('position', new THREE.BufferAttribute(starVertices,3)); const starMaterial=new THREE.PointsMaterial({ color:0xffffff, size:100 }); const stars=new THREE.Points(starGeometry, starMaterial);
            const dynamicObjects=[];
            function initRenderer(){ if(renderer&&renderer.domElement&&renderer.domElement.parentNode){ renderer.domElement.parentNode.removeChild(renderer.domElement); renderer.dispose(); } renderer=new THREE.WebGLRenderer({ antialias:true }); renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2)); const width=Math.max(10, container.clientWidth); const height=Math.max(10, container.clientHeight); renderer.setSize(width,height,false); renderer.domElement.style.display='block'; container.appendChild(renderer.domElement); camera.aspect=width/height; camera.updateProjectionMatrix(); }
            function pvToVector3(pos){ return new THREE.Vector3(pos.x, pos.z, pos.y); }
            function clearDynamicObjects(){ for(const obj of dynamicObjects){ if(obj.parent) obj.parent.remove(obj); if(obj.geometry) obj.geometry.dispose(); if(obj.material){ if(Array.isArray(obj.material)) obj.material.forEach(m=>{ if(m.dispose) m.dispose(); }); else if(obj.material.dispose) obj.material.dispose(); } } dynamicObjects.length=0; }
            function analyzeCollisionRisk(){ const s1idx=document.getElementById('sat1Select').value; const s2idx=document.getElementById('sat2Select').value; const duration=parseFloat(document.getElementById('duration').value); const threshold=parseFloat(document.getElementById('threshold').value); const samples=parseInt(document.getElementById('samples').value,10); const startTimeValue=document.getElementById('startTime').value; if(!s1idx||!s2idx){ document.getElementById('results').innerHTML='<div class="result-item" style="margin:8px 0;padding:8px;background:rgba(255,255,255,0.02);border-radius:8px;border-left:3px solid #ff6b6b;"><div class="result-label" style="color:#9fb0c9;font-size:0.85rem;">Error</div><div class="result-value" style="font-family:monospace;font-weight:700;font-size:1rem;color:#fff;">Select two satellites</div></div>'; return; } if(s1idx===s2idx){ document.getElementById('results').innerHTML='<div class="result-item" style="margin:8px 0;padding:8px;background:rgba(255,255,255,0.02);border-radius:8px;border-left:3px solid #ff6b6b;"><div class="result-label" style="color:#9fb0c9;font-size:0.85rem;">Error</div><div class="result-value" style="font-family:monospace;font-weight:700;font-size:1rem;color:#fff;">Please select two different satellites</div></div>'; return; } const satA=parsedTLEs[parseInt(s1idx,10)]; const satB=parsedTLEs[parseInt(s2idx,10)]; if(!satA||!satB||!satA.satrec||!satB.satrec){ document.getElementById('results').innerHTML='<div class="result-item" style="margin:8px 0;padding:8px;background:rgba(255,255,255,0.02);border-radius:8px;border-left:3px solid #ff6b6b;"><div class="result-label" style="color:#9fb0c9;font-size:0.85rem;">Error</div><div class="result-value" style="font-family:monospace;font-weight:700;font-size:1rem;color:#fff;">Invalid or unparsed TLE selection</div></div>'; return; }
              let analysisStartDate; if(startTimeValue){ const parts=startTimeValue.split('T'); if(parts.length===2){ const d=parts[0].split('-').map(Number); const t=parts[1].split(':').map(Number); analysisStartDate=new Date(Date.UTC(d[0],d[1]-1,d[2],t[0],t[1], (t[2]?parseInt(t[2]):0))); } else { analysisStartDate=new Date(startTimeValue); } } else { analysisStartDate=new Date(); }
              clearDynamicObjects(); const pathPointsCount=Math.min(1000, Math.max(100, Math.floor(samples/2))); const path1Points=[]; const path2Points=[]; for(let i=0;i<=pathPointsCount;i++){ const t_hours=(i/pathPointsCount)*duration; const sampleDate=new Date(analysisStartDate.getTime()+Math.round(t_hours*3600*1000)); const p1=satellite.propagate(satA.satrec, sampleDate); const p2=satellite.propagate(satB.satrec, sampleDate); if(p1.position) path1Points.push(pvToVector3(p1.position)); if(p2.position) path2Points.push(pvToVector3(p2.position)); }
              if(path1Points.length>0){ const geom1=new THREE.BufferGeometry().setFromPoints(path1Points); const mat1=new THREE.LineBasicMaterial({ color: satA.color, linewidth:1 }); const line1=new THREE.Line(geom1, mat1); scene.add(line1); dynamicObjects.push(line1); }
              if(path2Points.length>0){ const geom2=new THREE.BufferGeometry().setFromPoints(path2Points); const mat2=new THREE.LineBasicMaterial({ color: satB.color, linewidth:1 }); const line2=new THREE.Line(geom2, mat2); scene.add(line2); dynamicObjects.push(line2); }
              let minDist=Infinity, minTimeHours=0, minPosA=null, minPosB=null; for(let i=0;i<=samples;i++){ const t_hours=(i/samples)*duration; const sampleDate=new Date(analysisStartDate.getTime()+Math.round(t_hours*3600*1000)); const p1=satellite.propagate(satA.satrec, sampleDate); const p2=satellite.propagate(satB.satrec, sampleDate); if(!p1.position||!p2.position) continue; const v1=pvToVector3(p1.position); const v2=pvToVector3(p2.position); const dist=v1.distanceTo(v2); if(dist<minDist){ minDist=dist; minTimeHours=t_hours; minPosA=v1.clone(); minPosB=v2.clone(); } }
              if(!minPosA||!minPosB){ document.getElementById('results').innerHTML='<div class="result-item" style="margin:8px 0;padding:8px;background:rgba(255,255,255,0.02);border-radius:8px;border-left:3px solid #ff6b6b;"><div class="result-label" style="color:#9fb0c9;font-size:0.85rem;">Error</div><div class="result-value" style="font-family:monospace;font-weight:700;font-size:1rem;color:#fff;">Propagation failed (TLE too old or invalid).</div></div>'; return; }
              const markerGeom=new THREE.SphereGeometry(Math.max(150, R_EARTH*0.018),12,12); const mA=new THREE.Mesh(markerGeom, new THREE.MeshBasicMaterial({ color: satA.color })); mA.position.copy(minPosA); scene.add(mA); dynamicObjects.push(mA); const mB=new THREE.Mesh(markerGeom, new THREE.MeshBasicMaterial({ color: satB.color })); mB.position.copy(minPosB); scene.add(mB); dynamicObjects.push(mB); const missGeom=new THREE.BufferGeometry().setFromPoints([minPosA, minPosB]); const missMat=new THREE.LineBasicMaterial({ color: (minDist < parseFloat(document.getElementById('threshold').value) ? 0xff0000 : 0x00ff00), linewidth:2 }); const missLine=new THREE.Line(missGeom, missMat); scene.add(missLine); dynamicObjects.push(missLine);
              const tcaDate=new Date(analysisStartDate.getTime()+Math.round(minTimeHours*3600*1000)); const isCollision=minDist < parseFloat(document.getElementById('threshold').value); const statusIcon=isCollision?'⚠️':'✅'; const statusText=isCollision?'COLLISION RISK DETECTED':'Safe Separation';
              document.getElementById('results').innerHTML = \`
                <div class="results-grid">
                  <div class="res-label">Satellite A</div><div class="res-value">\${satA.name}</div>
                  <div class="res-label">Satellite B</div><div class="res-value">\${satB.name}</div>
                  <div class="res-label">Time of Closest Approach (TCA)</div><div class="res-value">\${tcaDate.toISOString()}</div>
                  <div class="res-label">Miss Distance</div><div class="res-value">\${minDist.toFixed(3)} km</div>
                </div>
                <div class="divider"></div>
                <div><span class="status-chip \${isCollision ? 'status-warn' : 'status-ok'}">\${statusIcon} \${statusText}</span></div>
              \`;
              const midpoint=minPosA.clone().add(minPosB).multiplyScalar(0.5); camera.lookAt(midpoint);
            }
            function animate(){ requestAnimationFrame(animate); earthGroup.rotation.y += 0.0003; if(renderer) renderer.render(scene, camera); }
            let isDragging=false; let prev={x:0,y:0}; const containerEl=document.getElementById('canvas-container');
            function init(){ containerEl.style.width='100%'; containerEl.style.height='100%'; initRenderer(); scene.add(stars); scene.add(ambientLight); scene.add(sunLight); scene.add(earthGroup); loadDefaultTLE(); animate(); }
            window.addEventListener('load', init); window.addEventListener('resize', ()=>{ if(!containerEl.clientWidth||!containerEl.clientHeight) return; initRenderer(); });
            containerEl.addEventListener('pointerdown',(e)=>{ isDragging=true; prev={x:e.clientX,y:e.clientY}; containerEl.setPointerCapture(e.pointerId); });
            containerEl.addEventListener('pointermove',(e)=>{ if(!isDragging) return; const dx=e.clientX-prev.x, dy=e.clientY-prev.y; prev={x:e.clientX,y:e.clientY}; const rotationSpeed=0.005; const yAxis=new THREE.Vector3(0,1,0); camera.position.applyAxisAngle(yAxis, -dx*rotationSpeed); const xAxis=new THREE.Vector3().crossVectors(camera.up, camera.position).normalize(); const newPos=camera.position.clone().applyAxisAngle(xAxis, -dy*rotationSpeed); if(newPos.y>-50000) camera.position.copy(newPos); camera.lookAt(0,0,0); });
            containerEl.addEventListener('pointerup',(e)=>{ isDragging=false; try{containerEl.releasePointerCapture(e.pointerId);}catch(_){} });
            containerEl.addEventListener('pointerleave', ()=>{ isDragging=false; });
            containerEl.addEventListener('wheel',(e)=>{ e.preventDefault(); if(!renderer) return; const zoomFactor=1+(e.deltaY>0?0.12:-0.12); const distance=camera.position.length(); const newDistance=distance*zoomFactor; const minDistance=15000, maxDistance=200000; if(newDistance>=minDistance && newDistance<=maxDistance) camera.position.multiplyScalar(newDistance/distance); }, { passive:false });
            document.getElementById('analyzeBtn').addEventListener('click', analyzeCollisionRisk);
            document.getElementById('resetBtn').addEventListener('click', ()=>{ camera.position.set(30000,20000,30000); camera.lookAt(0,0,0); });
            if (document.readyState === 'complete') { setTimeout(()=>{ if(!renderer) init(); }, 50); }
          })();
        `;
        const run = document.createElement('script'); run.textContent = scriptContent; document.body.appendChild(run); document.body.removeChild(run);
      } catch (e) {
        overlayStage.innerHTML = `<div style="color:#ff9b9b">Failed to load libraries: ${e.message}</div>`;
      }
      return;
    }
    overlayStage.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;">Running simulation... <span style="margin-left:12px">🔄</span></div>';

    try {
      const resp = await fetch('/run-simulation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sim_type: simType })
      });

      const data = await resp.json();
      if (!resp.ok || data.status !== 'success') {
        throw new Error(data.message || 'Server error');
      }

      
      const url = data.file;
      const ext = url.split('.').pop().toLowerCase();
      if (ext === 'html') {
        overlayStage.innerHTML = `<iframe src="${url}" style="width:100%;height:100%;border:0;border-radius:12px;"></iframe>`;
      } else if (ext === 'mp4') {
        overlayStage.innerHTML = `<video controls autoplay style="width:100%;height:100%;border-radius:12px;"><source src="${url}" type="video/mp4">Your browser does not support video.</video>`;
      } else {
        overlayStage.innerHTML = `<img src="${url}" alt="simulation result" style="width:100%;height:100%;object-fit:contain;border-radius:12px;">`;
      }

      
      const downloadBtn = document.querySelector('.overlay-actions .btn');
      if (downloadBtn) {
        downloadBtn.onclick = () => { window.open(url, '_blank'); }
      }

    } catch (err) {
      overlayStage.innerHTML = `<div style="color:#ff9b9b">Error: ${err.message}</div>`;
      console.error(err);
    }
  }

  
  document.querySelectorAll('[data-action="run"]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const simType = btn.closest('.sim-card').dataset.sim || 'orbit';
      runSimulation(simType);
    });
  });

  
  const runFirst = document.getElementById('run-first');
  if (runFirst) {
    runFirst.addEventListener('click', (e)=>{
      e.preventDefault();
      location.hash = '#simulations';
      runSimulation('orbit');
    });
  }

});